export interface UserProfile {
  uid: string;
  email: string;
  balance: number;
  ordersCount: number;
  totalSpend: number;
  isAdmin: boolean;
  referralCode?: string;
  myReferralId: string;
  referralEarnings: number;
  referralBalance: number;
  createdAt: string;
  seededJaatSammi?: boolean;
  seededJaatSammiV2?: boolean;
}

export interface Withdrawal {
  id: string;
  userId: string;
  userEmail: string;
  mobileNumber: string;
  upiId: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface SMMOrder {
  id: string;
  userId: string;
  serviceId: string;
  serviceName: string;
  link: string;
  quantity: number;
  charge: number;
  status: 'pending' | 'processing' | 'completed' | 'cancelled' | 'partial' | 'error';
  externalOrderId?: string;
  referralCode?: string;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  utr?: string;
  type: 'add_funds' | 'order';
  status: 'pending' | 'approved' | 'rejected';
  description?: string;
  createdAt: string;
}

export interface SMMService {
  service: string;
  name: string;
  type: string;
  category: string;
  rate: string;
  min: string;
  max: string;
  description: string;
  dripfeed: boolean;
  refill: boolean;
  cancel: boolean;
}
